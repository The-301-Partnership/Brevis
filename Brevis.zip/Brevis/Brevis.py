from tkinter import *
import pyshorteners
import pyperclip
from tkinter import messagebox

win = Tk()
win.title("Brevis")
win.iconbitmap(r'C:\Users\islan\PycharmProjects\Brevis\image.ico')
def shorten():
    global i
    url = entry.get()
    s = pyshorteners.Shortener()
    i = s.tinyurl.short(url)
    pyperclip.copy(i)
    spam = pyperclip.paste()
    messagebox.showinfo(title= "Success!", message = "You Shortened URL has been created, it is stored on your clipboard")
    win.destroy()


label1 = Label(win,text="Enter URL Here:"
               ,font=("arial", 10,"bold"))
label1.grid(row=0,column=0)

label2 = Label(win, text="The new URL will be automatically copied to your clipboard"
                   , font=("arial", 10, "bold"))
label2.grid(row=5, column=0,columnspan=2)
label3 = Label(win,text="Copyright © 2020 The-301-Partnership"
               ,font=("arial", 10,"bold"))
label3.grid(row=10,column=0,columnspan=2)

entry = Entry(win,width=30)
entry.grid(row=0,column=1)
button = Button(win,text="Shorten URL", command=shorten,)
button.grid(row=1,column=0,columnspan=2,pady=10)
__author__ = "The-301-Partnership"
__copyright__ = "Copyright (C)© 2020 The-301-Partnership"
__license__ = "MIT License"
__version__ = "1.0"

win.mainloop()